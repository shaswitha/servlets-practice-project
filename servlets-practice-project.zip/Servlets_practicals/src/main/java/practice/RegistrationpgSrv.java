package practice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistrationpgSrv extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String fnamereceived = req.getParameter("fname");
		String lnamereceived = req.getParameter("lname");
		String unamereceived = req.getParameter("uname");
		String passwordreceived = req.getParameter("password");

		User userObj = new User(0, fnamereceived, lnamereceived, unamereceived, passwordreceived);
		jdbchelper jdbcObj = new jdbchelper();
		int result = jdbcObj.insertUser(userObj);

		resp.setContentType("text/html");
		PrintWriter pwObj = resp.getWriter();
		pwObj.println("<h3>This is the response fron doGet method of RegistrationSrv program</h3>");

		if (result == 0) {
			pwObj.println("<h3 style='color:red' >Registration Failed</h3>");

		} else {
			pwObj.println("<h3 style='color:green' >Registration Success</h3>");

		}

	}

}
