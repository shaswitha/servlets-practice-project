package practice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class simple extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		resp.setContentType("text/html");

		PrintWriter ken = resp.getWriter();
		ken.println("hi");
		ken.println(30000);
		ken.println("shaswitha");

		ken.println("<h1> Tokyo Ghoul  </h1>");
		ken.close();
	}

}
