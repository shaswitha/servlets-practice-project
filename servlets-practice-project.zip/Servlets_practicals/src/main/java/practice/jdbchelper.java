package practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class jdbchelper {
	private Connection conObj;
	{

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/fs4_db", "root", "3306");
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	int insertUser(User user) {
		int result = 0;
		String query = "insert into user_tab(fname,  lname,  uname,  pwd) values (?, ?, ?, ?)";
		try {
			PreparedStatement pStmtObj = conObj.prepareStatement(query);
			pStmtObj.setString(1, user.getFname());
			pStmtObj.setString(2, user.getLname());
			pStmtObj.setString(3, user.getUname());
			pStmtObj.setString(4, user.getPassword());

			result = pStmtObj.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return result;
	}

	User getUser(int Id) {
		String query = "select * from user_tab where Id = ?";
		User userObj = new User();
		try {
			PreparedStatement pStmtObj = conObj.prepareStatement(query);
			pStmtObj.setInt(1, Id);
			ResultSet rsObj = pStmtObj.executeQuery();
			rsObj.next();

			userObj.setid(rsObj.getInt(1));
			userObj.setFname(rsObj.getString(2));
			userObj.setLname(rsObj.getString(3));
			userObj.setUname(rsObj.getString(4));
			userObj.setPassword(rsObj.getString(5));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userObj;
	}

	int UpdateUser(User user) {
		String query = "update user_tab set fname=?,lname = ?,uname= ?, pwd = ? where Id = ?";
		int result = 0;
		try {
			PreparedStatement pStmtObj = conObj.prepareStatement(query);
			pStmtObj.setString(1, user.getFname());
			pStmtObj.setString(2, user.getLname());
			pStmtObj.setString(3, user.getUname());
			pStmtObj.setString(4, user.getPassword());
			pStmtObj.setInt(5, user.getid());

			result = pStmtObj.executeUpdate();
			pStmtObj.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	int deleteUser(int Id) {
		String query = "delete from user_tab where id= ?";
		int result = 0;
		try {
			PreparedStatement pStmtObj = conObj.prepareStatement(query);
			pStmtObj.setInt(1, Id);
			result = pStmtObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
}
