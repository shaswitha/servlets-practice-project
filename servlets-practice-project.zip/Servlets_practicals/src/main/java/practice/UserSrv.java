package practice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserSrv extends HttpServlet {
	private jdbchelper JdbcHelper;

//	to get or to read the user_tab to browser
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String IdReceived = req.getParameter("Id");
		int id = Integer.parseInt(IdReceived); // to conver Id from String to Integer format
		User user = JdbcHelper.getUser(id);

		resp.setContentType("text/html");
		PrintWriter pwObj = resp.getWriter();

		pwObj.println("<h2>Id is " + user.getid() + "</h2>");
		pwObj.println("<h2>First Name is " + user.getFname() + "</h2>");
		pwObj.println("<h2>Last Name is " + user.getLname() + "</h2>");
		pwObj.println("<h2>user Name is " + user.getUname() + "</h2>");
		pwObj.println("<h2>Password is " + user.getPassword() + "</h2>");
		pwObj.close();
	}

//   to insert the data into the user_tab  
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fnamereceived = req.getParameter("fname");
		String lnamereceived = req.getParameter("lname");
		String unamereceived = req.getParameter("uname");
		String passwordreceived = req.getParameter("password");

		User userObj = new User(0, fnamereceived, lnamereceived, unamereceived, passwordreceived);
//		jdbchelper jdbcObj = new jdbchelper();
		int result = JdbcHelper.insertUser(userObj);

		resp.setContentType("text/html");
		PrintWriter pwObj = resp.getWriter();
		pwObj.println("<h3>This is the response from doGet method of UserSrv program</h3>");

		if (result == 0) {
			pwObj.println("<h3 style='color:red' >Registration Failed</h3>");

		} else {
			pwObj.println("<h3 style='color:green' >Registration Success</h3>");

		}

	}

//     to update the data in user_tab
	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int Id = Integer.parseInt(req.getParameter("Id"));
		String fnamereceived = req.getParameter("fname");
		String lnamereceived = req.getParameter("lname");
		String unamereceived = req.getParameter("uname");
		String passwordreceived = req.getParameter("password");

		User userObj = new User(Id, fnamereceived, lnamereceived, unamereceived, passwordreceived);
//		jdbchelper jdbcObj = new jdbchelper();
		int result = JdbcHelper.UpdateUser(userObj);

		resp.setContentType("text/html");
		PrintWriter pwObj = resp.getWriter();
		pwObj.println("<h3>This is the response from doPut method of UserSrv program</h3>");

		if (result == 0) {
			pwObj.println("<h3 style='color:red' >Update Failed</h3>");

		} else {
			pwObj.println("<h3 style='color:green' >Update Success</h3>");

		}

	}

//     to delete the data from the user_tab
	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int Id = Integer.parseInt(req.getParameter("Id"));

		int result = JdbcHelper.deleteUser(Id);

		resp.setContentType("text/html");
		PrintWriter pwObj = resp.getWriter();
		pwObj.println("<h3>This is the response from doDelete method of UserSrv program</h3>");

		if (result == 0) {
			pwObj.println("<h3 style='color:red' >Delete Failed</h3>");

		} else {
			pwObj.println("<h3 style='color:green' >Delete Success</h3>");

		}

	}
}
